import { useState, useEffect } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Laptop,
  Recycle,
  Wrench,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { ContactForm } from '../components/ContactForm';
import { SectionTitle } from '../components/SectionTitle';

// Slider Component
function HeroSlider() {
  const images = [
    'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1618424181497-157f25b6ddd5?q=80&w=1000&auto=format&fit=crop',
    'https://img.freepik.com/premium-photo/laptop-with-accessories-energy-information-safety-concept_392895-348666.jpg',
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <div className="relative h-[520px] w-full">
      <div className="absolute -inset-5 rounded-[3rem] bg-gradient-to-r from-cyan-300/30 to-violet-500/30 blur-2xl" />
      {images.map((img, index) => (
        <img
          key={index}
          src={img}
          alt={`Slide ${index}`}
          className={`absolute inset-0 h-full w-full rounded-[3rem] object-cover shadow-2xl shadow-cyan-950/40 transition-opacity duration-1000 ease-in-out ${
            index === currentIndex ? 'opacity-100' : 'opacity-0'
          }`}
        />
      ))}
      <div className="absolute inset-0 rounded-[3rem] bg-black/20" />
    </div>
  );
}

export function Home() {
  const services = [
    {
      icon: Laptop,
      title: 'Laptop Sales',
      text: 'New and certified used laptops.',
      path: '/new-laptops',
    },
    {
      icon: Recycle,
      title: 'Old Laptop Purchase',
      text: 'Sell your old, damaged or unused laptop.',
      path: '/sell-laptop',
    },
    {
      icon: Wrench,
      title: 'Repair Center',
      text: 'Screen, keyboard, battery, motherboard.',
      path: '/repairs',
    },
  ];

  return (
    <div className="bg-slate-950 text-white">
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_20%,rgba(34,211,238,0.2),transparent_35%),radial-gradient(circle_at_80%_10%,rgba(124,58,237,0.22),transparent_30%),linear-gradient(135deg,#020617,#0f172a_55%,#111827)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-28">
          <div>
            <h1 className="text-5xl font-black tracking-tight sm:text-6xl lg:text-7xl">
              Buy, sell, repair & upgrade laptops in one trusted store.
            </h1>
            <p className="mt-6 text-lg text-slate-300">
              Techbazar offers new laptops, certified used laptops, old laptop
              purchase, fast repairs and premium accessories.
            </p>
            <div className="mt-9 flex gap-4">
              <Link
                to="/new-laptops"
                className="rounded-full bg-cyan-300 px-7 py-4 font-black text-slate-950 hover:bg-white"
              >
                Shop New
              </Link>
              <Link
                to="/repairs"
                className="rounded-full border border-white/15 px-7 py-4 font-black text-white hover:bg-cyan-300/10"
              >
                Book Repair
              </Link>
            </div>
          </div>
          <div className="relative">
            <HeroSlider />
            <div className="absolute -bottom-6 left-6 right-6 grid grid-cols-3 rounded-[2rem] border border-white/15 bg-slate-950/85 p-5 backdrop-blur">
              {[
                ['500+', 'Sold'],
                ['1 Day', 'Repair'],
                ['6 Mo', 'Warranty'],
              ].map(([val, label]) => (
                <div key={label} className="text-center">
                  <p className="text-xl font-black text-cyan-300">{val}</p>
                  <p className="text-xs font-bold">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionTitle
          eyebrow="What We Do"
          title="Separate services, one smooth experience"
          text="Click any service to navigate."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {services.map((s) => (
            <Link
              key={s.title}
              to={s.path}
              className="group rounded-[2rem] border border-white/10 bg-white/[0.06] p-7 hover:border-cyan-300/50"
            >
              <s.icon className="h-12 w-12 text-cyan-300" />
              <h3 className="mt-6 text-2xl font-black">{s.title}</h3>
              <p className="mt-3 text-slate-300">{s.text}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20">
        <ContactForm compact />
      </section>
    </div>
  );
}
