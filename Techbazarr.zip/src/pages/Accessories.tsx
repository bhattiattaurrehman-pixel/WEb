import { Link } from 'react-router-dom';
import { SectionTitle } from '../components/SectionTitle';
import { accessories } from '../data/site';

export function Accessories() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="Accessories"
          title="Laptop accessories and spare parts"
          text="Chargers, SSDs, RAM, bags, cooling pads, keyboards, mouse, headsets and daily-use laptop essentials."
        />

        <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.06] lg:grid lg:grid-cols-[0.9fr_1.1fr] mt-12 items-stretch">
          {/* Main Display Left Section - Strictly Square Balanced Frame */}
          <div className="relative aspect-square w-full bg-slate-900 border-r border-white/5">
            <img
              src="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80"
              alt="Premium Computer Accessories Showcase"
              className="w-full h-full object-cover opacity-90"
            />
          </div>

          {/* Right Section - Items Sub-Grid */}
          <div className="grid gap-4 p-6 sm:grid-cols-2 lg:p-8">
            {accessories &&
              accessories.map((item) => (
                <article
                  key={item.name}
                  className="rounded-3xl border border-white/10 bg-slate-950/60 p-5 transition-all duration-300 hover:border-cyan-300/50 hover:bg-cyan-300/5"
                >
                  {/* Dynamically checking if icon is a functional component before rendering */}
                  {item.icon && typeof item.icon !== 'string' ? (
                    <item.icon className="h-9 w-9 text-cyan-300" />
                  ) : (
                    <span className="text-2xl block">🔌</span>
                  )}

                  <p className="mt-4 text-xs font-black uppercase tracking-[0.2em] text-cyan-200">
                    {item.category}
                  </p>
                  <h3 className="mt-2 text-xl font-black text-slate-100">
                    {item.name}
                  </h3>
                  <p className="mt-2 text-sm text-slate-300 line-clamp-2 leading-relaxed">
                    {item.detail}
                  </p>

                  <div className="mt-4 flex items-center justify-between pt-2 border-t border-white/5">
                    <span className="text-2xl font-black text-cyan-300">
                      {item.price}
                    </span>
                    <Link
                      to="/contact"
                      className="rounded-full bg-white px-4 py-2 text-sm font-black text-slate-950 hover:bg-cyan-200 transition-colors"
                    >
                      Buy
                    </Link>
                  </div>
                </article>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
