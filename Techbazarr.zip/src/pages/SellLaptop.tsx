import {
  Calculator,
  CheckCircle2,
  ClipboardCheck,
  HandCoins,
  Laptop,
} from 'lucide-react';
import { ContactForm } from '../components/ContactForm';
import { SectionTitle } from '../components/SectionTitle';

export function SellLaptop() {
  const steps = [
    {
      icon: Laptop,
      title: 'Share Details',
      text: 'Send brand, model, processor, RAM, storage and condition photos.',
    },
    {
      icon: Calculator,
      title: 'Get Estimate',
      text: 'We calculate market value and condition-based offer.',
    },
    {
      icon: ClipboardCheck,
      title: 'Inspection',
      text: 'Technician checks battery, display, body and performance.',
    },
    {
      icon: HandCoins,
      title: 'Instant Payment',
      text: 'Accept the offer and receive payment immediately.',
    },
  ];

  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="We Purchase"
          title="Sell your old laptop at a fair price"
          text="Working, slow, damaged or unused laptops are welcome. Get a transparent valuation without pressure."
        />
        <div className="grid gap-6 md:grid-cols-4">
          {steps.map((step, index) => (
            <div
              key={step.title}
              className="relative rounded-[2rem] border border-white/10 bg-white/[0.06] p-6"
            >
              <div className="mb-5 flex items-center justify-between">
                <step.icon className="h-10 w-10 text-cyan-300" />
                <span className="text-4xl font-black text-white/10">
                  0{index + 1}
                </span>
              </div>
              <h3 className="text-xl font-black">{step.title}</h3>
              <p className="mt-3 text-slate-300">{step.text}</p>
            </div>
          ))}
        </div>
        <div className="mt-14 grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-cyan-300/15 to-violet-500/15 p-8">
            <h3 className="text-3xl font-black">We buy these conditions</h3>
            <ul className="mt-6 space-y-4">
              {[
                'Excellent working laptops',
                'Slow laptops needing upgrade',
                'Broken screen laptops',
                'No power or liquid damaged units',
                'Bulk office laptop lots',
              ].map((item) => (
                <li key={item} className="flex gap-3 text-slate-200">
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-300" />{' '}
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
