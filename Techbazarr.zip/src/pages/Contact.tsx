import { Clock, Mail, MapPin, Phone } from 'lucide-react';
import { ContactForm } from '../components/ContactForm';
import { SectionTitle } from '../components/SectionTitle';

export function Contact() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="Contact"
          title="Visit, call or send an enquiry"
          text="Use this page for laptop purchase, selling old laptop, repair booking, accessory orders or business bulk requests."
        />

        <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] mt-12 items-start">
          <div className="space-y-4">
            {/* Interactive Contact Cards */}
            {[
              {
                icon: Phone,
                title: 'Phone',
                text: '+92 (300) 123-4567',
                href: 'tel:+923001234567',
                isLink: true,
              },
              {
                icon: Mail,
                title: 'Email',
                text: 'sales@technova.pk',
                href: 'mailto:sales@technova.pk',
                isLink: true,
              },
              {
                icon: MapPin,
                title: 'Address',
                text: 'Hall Road, Digital Market, Lahore',
                href: 'https://maps.google.com',
                isLink: true,
              },
            ].map((item) => (
              <a
                key={item.title}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex gap-5 rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 transition-all duration-300 hover:border-cyan-300/50 hover:bg-cyan-300/5"
              >
                <item.icon className="h-9 w-9 shrink-0 text-cyan-300" />
                <div>
                  <h3 className="text-xl font-black text-slate-100">
                    {item.title}
                  </h3>
                  <p className="mt-1 text-slate-300 text-sm">{item.text}</p>
                </div>
              </a>
            ))}

            {/* Non-Link Info Card for Timings */}
            <div className="flex gap-5 rounded-[2rem] border border-white/10 bg-white/[0.06] p-6">
              <Clock className="h-9 w-9 shrink-0 text-cyan-300" />
              <div>
                <h3 className="text-xl font-black text-slate-100">
                  Opening Hours
                </h3>
                <p className="mt-1 text-slate-300 text-sm">
                  Mon–Sat: 10:00 AM – 8:00 PM
                </p>
              </div>
            </div>

            {/* Simulated Interactive Map Block */}
            <div className="rounded-[2rem] border border-white/10 bg-slate-900 p-4">
              <div className="grid h-64 place-items-center rounded-[1.5rem] bg-[linear-gradient(135deg,rgba(34,211,238,.12),rgba(124,58,237,.12)),repeating-linear-gradient(45deg,rgba(255,255,255,.02)_0_1px,transparent_1px_18px)] text-center border border-white/5">
                <div>
                  <MapPin className="mx-auto mb-3 h-10 w-10 text-cyan-300" />
                  <p className="font-black text-slate-100">Store Map Area</p>
                  <p className="text-sm text-slate-400 mt-1">
                    Hall Road, Lahore, Pakistan
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Inquiry Form handling right grid block */}
          <div className="bg-white/[0.02] border border-white/10 rounded-[2rem] p-6 sm:p-8 backdrop-blur-sm">
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  );
}
