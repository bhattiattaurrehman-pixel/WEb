import { ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ProductCard } from '../components/ProductCard';
import { SectionTitle } from '../components/SectionTitle';
import { usedLaptops } from '../data/site';

export function UsedLaptops() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="Certified Used"
          title="Old and refurbished laptops for sale"
          text="Inspected, cleaned, tested and ready-to-use laptops at affordable prices."
        />
        <div className="mb-12 grid gap-4 md:grid-cols-3">
          {[
            'Battery health checked',
            'Fresh OS installed',
            'Warranty available',
          ].map((item) => (
            <div
              key={item}
              className="flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] p-4 font-bold text-slate-200"
            >
              <ShieldCheck className="h-5 w-5 text-emerald-300" /> {item}
            </div>
          ))}
        </div>
        <div className="grid gap-7 md:grid-cols-2 xl:grid-cols-4">
          {usedLaptops.map((item) => (
            <ProductCard key={item.name} item={item} />
          ))}
        </div>
        <div className="mt-14 text-center">
          <Link
            to="/sell-laptop"
            className="inline-flex rounded-full border border-cyan-300 px-7 py-4 font-black text-cyan-100 transition hover:-translate-y-1 hover:bg-cyan-300 hover:text-slate-950"
          >
            Want to sell your old laptop?
          </Link>
        </div>
      </div>
    </div>
  );
}
