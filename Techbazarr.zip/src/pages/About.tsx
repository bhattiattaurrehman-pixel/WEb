import { Award, HeartHandshake, Shield, Users } from 'lucide-react';
import { SectionTitle } from '../components/SectionTitle';

export function About() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="About Us"
          title="A modern laptop store built on trust"
          text="TechNova helps customers buy the right laptop, sell old devices honestly and repair machines with professional care."
        />
        <div className="grid gap-8 lg:grid-cols-2 items-stretch mt-12">
          {/* Main Highlights Display Image */}
          <div className="relative aspect-square w-full rounded-[2rem] overflow-hidden bg-slate-900 border border-white/5 shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&q=80"
              alt="TechNova Premium Laptop Store Showcase"
              className="w-full h-full object-cover opacity-90 hover:scale-102 transition-transform duration-500"
            />
          </div>

          {/* Features Loop */}
          <div className="space-y-6 flex flex-col justify-between">
            {[
              {
                icon: Users,
                title: 'Customer-first advice',
                text: 'We recommend laptops based on real work needs, not only price.',
              },
              {
                icon: Shield,
                title: 'Tested parts and devices',
                text: 'Used laptops and accessories are checked before sale.',
              },
              {
                icon: Award,
                title: 'Experienced technicians',
                text: 'Our repair team works on common and complex laptop faults.',
              },
              {
                icon: HeartHandshake,
                title: 'Long-term support',
                text: 'After-sale help, warranty guidance and upgrade support are always available.',
              },
            ].map((item) => (
              <div
                key={item.title}
                className="flex gap-5 rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 backdrop-blur-sm hover:border-cyan-500/30 transition-colors"
              >
                <item.icon className="h-10 w-10 shrink-0 text-cyan-300" />
                <div>
                  <h3 className="text-2xl font-black text-slate-100">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-slate-300 text-sm leading-relaxed">
                    {item.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
