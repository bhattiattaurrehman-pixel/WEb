import { Link } from 'react-router-dom';
import { SectionTitle } from '../components/SectionTitle';
import { repairServices } from '../data/site';

export function Repairs() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="Repair Lab"
          title="Laptop repair services with warranty"
          text="From simple software fixes to motherboard level repair, our technicians handle all brands carefully."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {repairServices.map((service) => (
            <article
              key={service.title}
              className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-7 transition duration-500 hover:-translate-y-2 hover:border-cyan-300/50"
            >
              <service.icon className="h-12 w-12 text-cyan-300" />
              <h3 className="mt-6 text-2xl font-black">{service.title}</h3>
              <p className="mt-3 leading-7 text-slate-300">
                {service.description}
              </p>
              <div className="mt-6 flex items-center justify-between rounded-2xl bg-slate-950/60 p-4">
                <span>
                  <strong className="block text-cyan-300">Price</strong>
                  {service.price}
                </span>
                <span className="text-right">
                  <strong className="block text-cyan-300">Time</strong>
                  {service.time}
                </span>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-14 overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.06] lg:grid lg:grid-cols-2">
          <img
            src="/images/laptop-repair-shop.jpg"
            alt="Laptop repair"
            className="h-full min-h-80 w-full object-cover"
          />
          <div className="p-8 lg:p-12">
            <h3 className="text-4xl font-black">Emergency repair desk</h3>
            <p className="mt-5 text-lg leading-8 text-slate-300">
              Bring your laptop for same-day checking. We explain the fault,
              repair options and exact estimate before work starts.
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex rounded-full bg-cyan-300 px-7 py-4 font-black text-slate-950 transition hover:-translate-y-1 hover:bg-white"
            >
              Book Repair Now
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
