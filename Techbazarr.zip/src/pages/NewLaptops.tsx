import { Link } from 'react-router-dom';
import { ProductCard } from '../components/ProductCard';
import { SectionTitle } from '../components/SectionTitle';
import { brands, newLaptops } from '../data/site';

export function NewLaptops() {
  return (
    <div className="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionTitle
          eyebrow="Brand New"
          title="New laptops for every budget"
          text="Latest models with box pack condition, warranty, software setup and after-sale support."
        />
        <div className="mb-10 flex flex-wrap justify-center gap-3">
          {brands.map((brand) => (
            <span
              key={brand}
              className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-sm font-bold text-cyan-100"
            >
              {brand}
            </span>
          ))}
        </div>
        <div className="grid gap-7 md:grid-cols-2 xl:grid-cols-4">
          {newLaptops.map((item) => (
            <ProductCard key={item.name} item={item} />
          ))}
        </div>
        <div className="mt-14 rounded-[2rem] border border-white/10 bg-gradient-to-r from-cyan-300/15 to-violet-500/15 p-8 text-center">
          <h3 className="text-3xl font-black">Need a custom model?</h3>
          <p className="mt-3 text-slate-300">
            Tell us your budget and usage. We will suggest the best laptop for
            study, office, gaming or business.
          </p>
          <Link
            to="/contact"
            className="mt-6 inline-flex rounded-full bg-cyan-300 px-7 py-4 font-black text-slate-950 transition hover:-translate-y-1 hover:bg-white"
          >
            Request Recommendation
          </Link>
        </div>
      </div>
    </div>
  );
}
