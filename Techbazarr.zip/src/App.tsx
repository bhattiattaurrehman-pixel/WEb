import { AnimatePresence } from 'framer-motion';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { PageTransition } from './components/PageTransition';
import { About } from './pages/About';
import { Accessories } from './pages/Accessories';
import { Contact } from './pages/Contact';
import { Home } from './pages/Home';
import { NewLaptops } from './pages/NewLaptops';
import { Repairs } from './pages/Repairs';
import { SellLaptop } from './pages/SellLaptop';
import { UsedLaptops } from './pages/UsedLaptops';
import './App.css';

function AnimatedRoutes() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <PageTransition>
              <Home />
            </PageTransition>
          }
        />
        <Route
          path="/new-laptops"
          element={
            <PageTransition>
              <NewLaptops />
            </PageTransition>
          }
        />
        <Route
          path="/used-laptops"
          element={
            <PageTransition>
              <UsedLaptops />
            </PageTransition>
          }
        />
        <Route
          path="/sell-laptop"
          element={
            <PageTransition>
              <SellLaptop />
            </PageTransition>
          }
        />
        <Route
          path="/repairs"
          element={
            <PageTransition>
              <Repairs />
            </PageTransition>
          }
        />
        <Route
          path="/accessories"
          element={
            <PageTransition>
              <Accessories />
            </PageTransition>
          }
        />
        <Route
          path="/about"
          element={
            <PageTransition>
              <About />
            </PageTransition>
          }
        />
        <Route
          path="/contact"
          element={
            <PageTransition>
              <Contact />
            </PageTransition>
          }
        />
        <Route
          path="*"
          element={
            <PageTransition>
              <Home />
            </PageTransition>
          }
        />
      </Routes>
    </AnimatePresence>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-950 font-sans text-white">
        <Header />
        <AnimatedRoutes />
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
