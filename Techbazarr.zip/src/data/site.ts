import { Cpu, HardDrive, Headphones, Laptop, Monitor, ShieldCheck, ShoppingBag, Sparkles, Wrench, Zap } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export type LaptopItem = {
  name: string
  tag: string
  price: string
  specs: string[]
  badge: string
  image: string
}

export type ServiceItem = {
  icon: LucideIcon
  title: string
  description: string
  price: string
  time: string
}

export const navItems = [
  { label: 'Home', path: '/' },
  { label: 'New Laptops', path: '/new-laptops' },
  { label: 'Used Laptops', path: '/used-laptops' },
  { label: 'Sell Your Laptop', path: '/sell-laptop' },
  { label: 'Repairs', path: '/repairs' },
  { label: 'Accessories', path: '/accessories' },
  { label: 'About', path: '/about' },
  { label: 'Contact', path: '/contact' },
]

export const highlights = [
  { icon: ShieldCheck, title: 'Warranty Included', text: 'Every laptop and repair comes with clear written warranty support.' },
  { icon: Zap, title: 'Fast Service', text: 'Most diagnostics are completed the same day with quick status updates.' },
  { icon: ShoppingBag, title: 'Buy, Sell, Repair', text: 'A complete laptop store for new, used, exchange, repair and accessories.' },
]

export const newLaptops: LaptopItem[] = [
  {
    name: 'Dell Inspiron 15 Pro',
    tag: 'Office & Study',
    price: '$649',
    specs: ['Intel Core i5 13th Gen', '16GB RAM', '512GB SSD', '15.6” FHD Display'],
    badge: 'Best Seller',
    image: '/images/new-laptops-display.jpg',
  },
  {
    name: 'HP EliteBook 840 G10',
    tag: 'Business',
    price: '$899',
    specs: ['Intel Core i7', '16GB RAM', '1TB SSD', 'Backlit Keyboard'],
    badge: 'Premium',
    image: '/images/new-laptops-display.jpg',
  },
  {
    name: 'Lenovo IdeaPad Slim 5',
    tag: 'Student Pick',
    price: '$579',
    specs: ['AMD Ryzen 7', '16GB RAM', '512GB SSD', 'Lightweight Build'],
    badge: 'New Arrival',
    image: '/images/new-laptops-display.jpg',
  },
  {
    name: 'ASUS CreatorBook X',
    tag: 'Design & Editing',
    price: '$1,199',
    specs: ['Intel Core i7', 'RTX Graphics', '32GB RAM', 'Color Accurate Screen'],
    badge: 'Creator Choice',
    image: '/images/new-laptops-display.jpg',
  },
]

export const usedLaptops: LaptopItem[] = [
  {
    name: 'MacBook Pro 13 Refurbished',
    tag: 'Grade A',
    price: '$699',
    specs: ['Apple M1', '8GB RAM', '256GB SSD', 'Battery Health 91%'],
    badge: 'Certified Used',
    image: '/images/laptop-repair-shop.jpg',
  },
  {
    name: 'ThinkPad T480 Renewed',
    tag: 'Grade A+',
    price: '$329',
    specs: ['Intel Core i5', '16GB RAM', '512GB SSD', 'Business Durable'],
    badge: 'Budget Hero',
    image: '/images/laptop-repair-shop.jpg',
  },
  {
    name: 'Dell Latitude 5420',
    tag: 'Grade B+',
    price: '$399',
    specs: ['Intel Core i5 11th Gen', '16GB RAM', '256GB SSD', 'Fresh Windows'],
    badge: 'Hot Deal',
    image: '/images/laptop-repair-shop.jpg',
  },
  {
    name: 'HP ProBook 450 G8',
    tag: 'Grade A',
    price: '$449',
    specs: ['Intel Core i7', '16GB RAM', '512GB SSD', '6 Month Warranty'],
    badge: 'Ready Stock',
    image: '/images/laptop-repair-shop.jpg',
  },
]

export const repairServices: ServiceItem[] = [
  { icon: Wrench, title: 'Laptop Diagnosis', description: 'Complete hardware and software health check with written repair quote.', price: 'Free with repair', time: '30–60 min' },
  { icon: Monitor, title: 'Screen Replacement', description: 'Cracked, dim, flickering and dead display replacement for all major brands.', price: 'From $79', time: '2–4 hrs' },
  { icon: HardDrive, title: 'SSD & RAM Upgrade', description: 'Speed up old laptops with genuine SSD drives, RAM upgrades and data migration.', price: 'From $49', time: 'Same day' },
  { icon: Cpu, title: 'Motherboard Repair', description: 'Chip-level repair, charging IC, liquid damage cleaning and power failure fixes.', price: 'Quote based', time: '1–3 days' },
  { icon: ShieldCheck, title: 'Virus & Windows Setup', description: 'Fresh Windows, drivers, activation help, antivirus and performance tuning.', price: 'From $35', time: '1–2 hrs' },
  { icon: Laptop, title: 'Keyboard & Battery', description: 'Original and compatible keyboard, trackpad, hinges and battery replacement.', price: 'From $45', time: 'Same day' },
]

export const accessories = [
  { icon: Headphones, name: 'Gaming Headset', category: 'Audio', price: '$39', detail: 'Noise isolation microphone and comfortable cushions.' },
  { icon: Monitor, name: 'USB-C Docking Station', category: 'Docking', price: '$69', detail: 'HDMI, USB, Ethernet and power delivery in one hub.' },
  { icon: Sparkles, name: 'Laptop Cleaning Kit', category: 'Care', price: '$12', detail: 'Screen-safe spray, microfiber cloth and dust brush.' },
  { icon: Zap, name: '65W Fast Charger', category: 'Power', price: '$29', detail: 'Compatible Type-C charger with safety protection.' },
  { icon: HardDrive, name: '1TB External SSD', category: 'Storage', price: '$89', detail: 'Portable high speed backup storage for work and games.' },
  { icon: ShoppingBag, name: 'Premium Laptop Bag', category: 'Carry', price: '$25', detail: 'Water-resistant bag with padded laptop compartment.' },
]

export const brands = ['Dell', 'HP', 'Lenovo', 'Apple', 'ASUS', 'Acer', 'MSI', 'Samsung']
