interface SectionTitleProps {
  eyebrow: string;
  title: string;
  text: string;
}

export function SectionTitle({ eyebrow, title, text }: SectionTitleProps) {
  return (
    <div className="mx-auto mb-12 max-w-3xl text-center">
      <p className="mb-3 font-black uppercase tracking-[0.3em] text-cyan-300">{eyebrow}</p>
      <h2 className="text-4xl font-black tracking-tight text-white sm:text-5xl">{title}</h2>
      <p className="mt-5 text-lg leading-8 text-slate-300">{text}</p>
    </div>
  );
}