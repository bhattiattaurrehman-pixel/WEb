import { Facebook, Instagram, Mail, MapPin, Phone, Twitter } from 'lucide-react'
import { Link } from 'react-router-dom'
import { brands, navItems } from '../data/site'

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-slate-950 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div>
          <div className="mb-5 flex items-center gap-3">
          <div className="h-12 w-12 overflow-hidden rounded-xl border border-white/10 bg-slate-900 p-0.5">
<img 
  src="/images/logo.avif" 
  alt="TechBazar Logo" 
  className="h-full w-full object-cover rounded-lg"  />
</div>
            
            <div>
            <p className="text-2xl font-black tracking-tight uppercase">

Tech<span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">Bazar</span>

</p>
<span className="text-[9px] font-black uppercase tracking-widest text-slate-400 -mt-0.5">
                Premium Laptop Marketplace
              </span>
            </div>
          </div>
          <p className="max-w-xl leading-7 text-slate-300">
            We sell new laptops, certified used laptops, buy old laptops, repair all major brands and stock reliable accessories for students, gamers and businesses.
          </p>
          <div className="mt-6 flex gap-3">
            {/* Yahan keys ko unique kiya hai */}
            {[
              { Icon: Facebook, name: 'facebook' },
              { Icon: Instagram, name: 'instagram' },
              { Icon: Twitter, name: 'twitter' }
            ].map(({ Icon, name }) => (
              <a key={name} href="https://example.com" className="grid h-10 w-10 place-items-center rounded-full border border-white/10 text-slate-300 transition hover:border-cyan-300 hover:text-cyan-200" aria-label={`${name} profile`}>
                <Icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-5 text-lg font-black">Pages</h3>
          <div className="grid gap-3">
            {navItems.map((item) => (
              /* Yahan inline-block aur transition lagayi hai taake hover par aage move ho sake */
              <Link key={item.path} to={item.path} className="inline-block text-slate-300 transition-transform duration-200 hover:translate-x-1 hover:text-cyan-200">
                {item.label}
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-5 text-lg font-black">Visit Store</h3>
          <div className="space-y-4 text-slate-300">
            <p className="flex gap-3"><MapPin className="mt-1 h-5 w-5 flex-shrink-0 text-cyan-300" /> 7)p Eastern End Sagar Road Lahore, Punjab, Pakistan</p>
            <a href="tel:+15550199200" className="flex gap-3 transition hover:text-cyan-200"><Phone className="h-5 w-5 flex-shrink-0 text-cyan-300" /> +92 (309) 501-7321</a>
            <a href="mailto:sales@techbazar.example" className="flex gap-3 transition hover:text-cyan-200"><Mail className="h-5 w-5 flex-shrink-0 text-cyan-300" /> sales@techbazar.example</a>
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            {brands.map((brand) => (
              <span key={brand} className="rounded-full border border-white/10 px-3 py-1 text-xs font-bold text-slate-300">{brand}</span>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-4 py-5 text-center text-sm text-slate-400">
        © {new Date().getFullYear()} TechNova. All pages use shared header and footer with smooth transitions.
      </div>
    </footer>
  )
}