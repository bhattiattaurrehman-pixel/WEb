import { CheckCircle2, ShoppingCart } from 'lucide-react'
import { Link } from 'react-router-dom'
import type { LaptopItem } from '../data/site'

export function ProductCard({ item }: { item: LaptopItem }) {
  return (
    <article className="group overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.06] shadow-2xl shadow-slate-950/30 backdrop-blur transition duration-500 hover:-translate-y-2 hover:border-cyan-300/50">
      <div className="relative h-56 overflow-hidden">
        <img src={item.image} alt={item.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
        {/* z-10 daala hai taake badge hamesha top par chamke */}
        <span className="absolute left-5 top-5 z-10 rounded-full bg-cyan-300 px-3 py-1 text-xs font-black text-slate-950 shadow-md">{item.badge}</span>
      </div>
      <div className="p-6">
        <p className="mb-2 text-sm font-bold text-cyan-200">{item.tag}</p>
        <h3 className="text-2xl font-black text-white line-clamp-1">{item.name}</h3>
        <p className="mt-2 text-3xl font-black text-cyan-300">{item.price}</p>
        <ul className="mt-5 space-y-2">
          {/* Yahan key ko index ke sath unique kiya hai taake duplicate specs par error na aaye */}
          {item.specs.map((spec, index) => (
            <li key={`${spec}-${index}`} className="flex items-center gap-2 text-sm text-slate-300">
              <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-emerald-300" /> {spec}
            </li>
          ))}
        </ul>
        <div className="mt-6 grid grid-cols-2 gap-3">
          <Link to="/contact" className="rounded-full bg-white px-4 py-3 text-center text-sm font-black text-slate-950 transition hover:bg-cyan-200 active:scale-95">Ask Price</Link>
          <Link to="/contact" className="inline-flex items-center justify-center gap-2 rounded-full border border-white/15 px-4 py-3 text-sm font-bold text-white transition hover:border-cyan-300 hover:bg-cyan-300/10 active:scale-95">
            <ShoppingCart className="h-4 w-4" /> Order
          </Link>
        </div>
      </div>
    </article>
  )
}