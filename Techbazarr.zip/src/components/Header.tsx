import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'New Laptops', href: '/new-laptops' },
    { name: 'Used Laptops', href: '/used-laptops' },
    { name: 'Accessories', href: '/accessories' },
    { name: 'Repairs', href: '/repairs' },
    { name: 'Sell Laptop', href: '/sell-laptop' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* TECHBAZAR LOGO & BRAND */}
          <Link to="/" className="flex items-center gap-3 group">
            {/* Custom logo.avif wrapped in a crisp square frame */}
            <div className="relative flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-slate-900 border border-white/10 p-1 shadow-lg shadow-cyan-500/5 group-hover:scale-105 transition-transform duration-300">
              <img
                src="/images/logo.avif"
                alt="TechBazaar Brand Logo"
                className="h-full w-full object-cover rounded-lg"
              />
            </div>

            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-tight text-white uppercase">
                Tech
                <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">
                  Bazaar
                </span>
              </span>
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 -mt-0.5">
                Premium Laptop Marketplace
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`rounded-xl px-3 py-2 text-xs font-bold uppercase tracking-wider transition-all ${
                    isActive
                      ? 'bg-cyan-400 text-slate-950 shadow-md shadow-cyan-400/20'
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {item.name}
                </Link>
              );
            })}
          </nav>

          {/* Mobile Menu Toggle Button */}
          <div className="flex lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center rounded-xl p-2.5 text-slate-400 hover:bg-white/5 hover:text-white focus:outline-none"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar Flyout */}
      {isOpen && (
        <div className="lg:hidden border-t border-white/10 bg-slate-950 px-4 py-4 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setIsOpen(false)}
                className={`block rounded-xl px-4 py-3 text-sm font-bold uppercase tracking-wider transition-all ${
                  isActive
                    ? 'bg-cyan-400 text-slate-950'
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                {item.name}
              </Link>
            );
          })}
        </div>
      )}
    </header>
  );
}
