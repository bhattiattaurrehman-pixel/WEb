import { Send } from 'lucide-react'
import { useState } from 'react'

export function ContactForm({ compact = false }: { compact?: boolean }) {
  const [sent, setSent] = useState(false)

  if (sent) {
    return (
      <div className="rounded-[2rem] border border-emerald-300/20 bg-emerald-300/5 p-8 text-center shadow-2xl backdrop-blur">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-400/20 text-emerald-300">
          <Send className="h-6 w-6" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">Thank You!</h3>
        <p className="text-sm text-emerald-200/8xl max-w-sm mx-auto leading-relaxed">
          Your request is ready; our team will contact you shortly.
        </p>
      </div>
    )
  }

  return (
    <form
      className="rounded-[2rem] border border-white/10 bg-white/[0.07] p-6 shadow-2xl shadow-slate-950/30 backdrop-blur md:p-8"
      onSubmit={(event) => {
        event.preventDefault()
        setSent(true)
      }}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="grid gap-2 text-sm font-bold text-slate-200">
          Your Name
          <input required className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none transition focus:border-cyan-300" placeholder="Enter name" />
        </label>
        <label className="grid gap-2 text-sm font-bold text-slate-200">
          Phone Number
          <input required className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none transition focus:border-cyan-300" placeholder="Enter phone" />
        </label>
      </div>
      {!compact && (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="grid gap-2 text-sm font-bold text-slate-200">
            Email
            <input type="email" className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none transition focus:border-cyan-300" placeholder="you@example.com" />
          </label>
          <label className="grid gap-2 text-sm font-bold text-slate-200">
            Service Needed
            <select className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none transition focus:border-cyan-300">
              <option>Buy New Laptop</option>
              <option>Buy Used Laptop</option>
              <option>Sell My Laptop</option>
              <option>Repair Service</option>
              <option>Accessories</option>
            </select>
          </label>
        </div>
      )}
      <label className="mt-4 grid gap-2 text-sm font-bold text-slate-200">
        Message
        <textarea required rows={compact ? 3 : 5} className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none transition focus:border-cyan-300" placeholder="Tell us what you need" />
      </label>
      <button type="submit" className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-cyan-300 px-6 py-4 font-black text-slate-950 transition hover:-translate-y-1 hover:bg-white">
        <Send className="h-5 w-5" /> Send Request
      </button>
    </form>
  )
}